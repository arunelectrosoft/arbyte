# Automotive Software
```mermaid
graph LR
Vehicle-->Gateway
Gateway-->Cloud
```